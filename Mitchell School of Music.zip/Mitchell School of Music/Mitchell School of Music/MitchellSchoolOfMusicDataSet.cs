﻿namespace Mitchell_School_of_Music
{


    partial class MitchellSchoolOfMusicDataSet
    {
    }
}

namespace Mitchell_School_of_Music.MitchellSchoolOfMusicDataSetTableAdapters {
    
    
    public partial class StudentTableAdapter {
    }
}
